Experiment Configuration File
=============================

.. autoattribute:: regions.RegionFileInterface.comments

TODO: Fixme

sd
    ads    
ads
    whoah
