Coding Conventions
==================

Indentation is 4 space characters
